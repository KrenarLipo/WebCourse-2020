//funksioni i shfaqjes se dates
function shfaqDaten(){
   document.getElementById('mydate').innerHTML = Date();
}
