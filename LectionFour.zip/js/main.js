console.log("Welcome");

function shfaqDaten(){
  document.getElementById('demo').innerHTML = Date();
  //document.write(3+4);
  //window.alert(3+4);
}

var numberone = 2;
var numbertwo = 3;
var rezultati = "Result: ";
var sum;
sum = numberone + numbertwo;
sum = 7;
//console.log(rezultati +''+ sum);

/* Assegnimi i  nje funksioni tek nje variabel */
function gjejShumen(a,b){
  return a+b;
}

sum = gjejShumen(5,6);
console.log(sum);

/* Funksioni i afishimit te gradave nga Ferheneit ne celsius */
function toCelsius(){
  var x = document.getElementById('grada').value;
  //return alert((5/9)*(x-32));
  //return (5/9)*(x-32);
  document.getElementById('resutGrada').innerHTML = (5/9)*(x-32);
}


//document.write("Ku jemi?");
