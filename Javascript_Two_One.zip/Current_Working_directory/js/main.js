var numernje = 1;
var numerdy = 4;

var shuma = 4+3;

//array me listen e makinave tona
var cars = ["Volvo","BMW", "Mercedez"];



console.log('Test pas Covidit');
console.log(shuma);

//es5

//let numernje;
//require
//lidhje me databasen
//llogaritje funksionale
//etj etj
//alert(numernje);
console.log(cars[2]);

//funksioni i shfaqjes se dates
function shfaqDaten(){
   document.getElementById('mydate').innerHTML = Date();
}

//funksioni qe gjen totalin e variablave me siper
function shfaqTotalin(){
  alert(numernje + numerdy);
}

//funksioni qe shfaq makinen e caktuar
function shfaqMakinen() {
  document.getElementById('makinaime').innerHTML = cars[2];
}

//magazinim makinash objekt
var makina = {
  modeli:"Range Rover",
  çmimi:20000,
  monedha:"Euro",
  vitiProdhimi:2008
};

//funksioni qe merr te dhenat nga nje objekt
function getCarFromObject(){
  document.getElementById('makinaime').innerHTML = makina["modeli"] + ' me çmim '+ makina["çmimi"] + ' ' + makina["monedha"] ;
}

//funksioni qe shfaq momentin e dites
var ora_aktuale = 13;
function getOrarDitor(){
  if(ora_aktuale < 10){
    document.getElementById("peshendetja").innerHTML = "Mirëmëngjes!";
  }else if(ora_aktuale < 12){
    document.getElementById("peshendetja").innerHTML = "Mirdita!";
  }else{
    document.getElementById("peshendetja").innerHTML = "Mirëmbrëma!";
  }
}

var dita = 2;
var day;
function switchCase(){
  switch(dita){             //if(dita = 1){ alert('Monday')}
    case 1:
      day = "Monday";
      //alert('Monday');
      break;
    case 6:              //if(dita = 2){ alert('Tuesday')}
      day = "Tuesday";
      //alert('Tuesday');
      break;
    case 2:             //if(dita = 3){ alert('Thursday')}
      day = "Thursday";
      //alert('Thursday');
      break;
  }
  document.getElementById("ditaime").innerHTML = "Today is " + day;
}
